import time

print("masukkan data dengan cara pisahkan dengan space!...")
data = [int(x) for x in input().split()]


def InsertionSort(data):
    for j in range(len(data)-1,-1,-1):
        value = data[j]
        hole = j
        while hole < (len(data)-1) and data[hole+1] > data[hole]:
            data[hole] = data[hole+1]
            hole = hole+1
            data[hole] = value
        print(data)

print("Data yang akan di sort", data)
print("Insertion Sort data :")
InsertionSort(data)
print("dalam 10 detik program akan mati!")
time.sleep(10)

