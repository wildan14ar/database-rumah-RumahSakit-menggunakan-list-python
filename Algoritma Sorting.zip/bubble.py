import time

print("masukkan data dengan cara pisahkan dengan space!...")
data = [int(x) for x in input().split()]


def BubbleSort(data):
    iterasi = 0
    for i in range(len(data) - 1):
        minimal = i
        for j in range(i + 1,len(data)):
            if data[j] < data[minimal]:
                minimal = j
        iterasi += 1
        data[minimal],data[i]=data[i],data[minimal]
        print(iterasi, data)

print('Data yang akan di sort :', data)
print('Bubble Sort data:')
BubbleSort(data)
print("dalam 10 detik program akan mati!")
time.sleep(10)


