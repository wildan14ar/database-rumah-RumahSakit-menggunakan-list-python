import time

print("masukkan data dengan cara pisahkan dengan space!...")
data = [int(x) for x in input().split()]

def ShellSort(data):
    subdatacount = len(data)//2
    while subdatacount > 0:
        for startposition in range(subdatacount):
            partion(data,startposition,subdatacount)
        subdatacount = subdatacount//2
    print(data)

def partion(data, start, gap):
    for i in range(start+gap,len(data),gap):
        currentvalue = data[i]
        position = 1
        while position>=gap and data[position-gap] > currentvalue:
            data[position] = data[position-gap]
            position = position-gap
        data[position] =currentvalue

print('Data yang akan di sort :', data)
print('Shell Sort data:')
ShellSort(data)
print("dalam 10 detik program akan mati!")
time.sleep(10)

