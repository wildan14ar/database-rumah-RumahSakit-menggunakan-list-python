import time

print("masukkan data dengan cara pisahkan dengan space!...")
data = [int(x) for x in input().split()]

def MergeSort(data):
    if len(data) > 1:
        mid = len(data) // 2
        L = data[:mid]
        R = data[mid:]

        MergeSort(L)
        MergeSort(R)
        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                data[k] = L[i]
                i = i+1
            else:
                data[k] = R[j]
                j = j+1
            k = k+1

        while i < len(L):
            data[k] = L[i]
            i = i+1
            k = k+1

        while j < len(R):
            data[k] = R[j]
            j = j+1
            k = k+1
    print(data)

print('Data yang akan di Sort :', data)
print('Merge Sort data:')
MergeSort(data)
print("dalam 10 detik program akan mati!")
time.sleep(10)
