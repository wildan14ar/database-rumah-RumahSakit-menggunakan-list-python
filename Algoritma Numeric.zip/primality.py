import time

print("Tes primality adalah algoritma untuk menentukan apakah nomor input adalah prima."
      "Di antara bidang matematika lainnya, ini digunakan untuk kriptografi. "
      "Tidak seperti faktorisasi integer, tes primality umumnya tidak memberikan faktor prima, hanya menyatakan apakah nomor input prima atau tidak.")

data = int(input("masukkan bilangan yang mau di chek: "))

def primaCheck(data):
    if data==1 or data==0 or (data % 2 == 0 and data > 2):
        print("bilangan {} bukan bilangan prima".format(data))
    else:
        for i in range(3, int(data**(1/2))+1, 2):
            if data%i == 0:
                print("bilangan {} bukan bilangan prima".format(data))
        print("bilangan {} adalah bilangan prima".format(data))

primaCheck(data)
time.sleep(10)
