import time

print("Fibonacci adalah suatu barisan bilangan yang merupakan hasil penjumlahan dua bilangan sebelumnya.")
x = int(input("masukkan range yang mau di keluarkan: "))

num1 = int(input("masukkan bilangan pertama: "))
num2 = int(input("masukkan bilangan kedua: "))
f = [num1,num2]

for i in range(0,x):
    num3 = num1+num2
    f.append(num3)
    num1 = num2
    num2 = num3

print("Fibonacchi dari bilangan {} dan {} dengan range {} adalah.".format(num1,num2,x), f)
time.sleep(10)