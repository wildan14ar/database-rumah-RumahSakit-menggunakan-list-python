import time

print("Faktor Persekutuan Terbesar (FPB) atau dalam bahasa Inggris sering disebut Greatest Common Divisor (GCD) dari dua buah bilangan"
      "adalah bilangan positif terbesar yang dapat membagi habis kedua bilangan tersebut.")

num1 = int(input("masukkan bilangan pertama: "))
num2 = int(input("masukkan bilangan kedua: "))

def hitung_FPB(x, y):
   while(y):
       x, y = y, x % y
   return x

fpb = hitung_FPB(num1, num2)
print("FPB dari bilangan {} dan {} adalah".format(num1,num2), fpb)
time.sleep(10)