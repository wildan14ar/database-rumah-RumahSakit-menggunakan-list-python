import time

print("""faktorial = Dalam matematika, yang dimaksud faktorial adalah hasil perkalian semua bilangan bulat positif yang kurang dari atau sama dengan bilangan. 
Faktorial sering dinotasikan menggunakan ! (tanda seru).
Contoh: 5! = 5 * 4 * 3 * 2 * 1 = 120""")

data = int(input("masukkan bilangan yang akan di faktorial-kan: "))

def faktorial(data):
    hasil = 1
    for i in range(2, data + 1):
        hasil *= i
    return hasil

print("hasil faktorial dari bilangan {} adalah: ".format(data))
print(faktorial(data))
time.sleep(10)